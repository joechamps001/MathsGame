package com.example.mathgameapplication;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import org.w3c.dom.Text;

class HomeActivity extends AppCompatActivity {
    private Button buttonAddition;
    private Button buttonMulti;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mathshomepage);

        buttonAddition = (Button) findViewById(R.id.button_add);
        buttonMulti = (Button) findViewById(R.id.button_multi);


        buttonAddition.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityMain();
                finish();
            }
        });

        buttonMulti.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitySubtraction();
                finish();
            }
        });
    }


    public void openActivityMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openActivitySubtraction() {
        Intent intent = new Intent(this,multiplicationActivity.class);
        startActivity(intent);
    }
}